/*
 * PreLab-5.c
 *
 * Created: 4/5/2025 11:03:53 PM
 * Author : edvin
 * Description: El prelab consiste en modificar el brillo de un led con un potenci�metro
 */ 
//*********************************************
// Encabezado (Libraries)
#define F_CPU 16000000
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "PWM1/PWM1.h"

uint8_t adc_read;
uint16_t dutyCycle;
uint16_t adc_map;

//*********************************************
// Function prototypes
void setup();
void initADC();

//*********************************************
// Main Function

int main(void)
{
	setup();	// Se manda a llamar la funci�n de Setup
	
	while(1)	// Entra al bucle infinito en donde se ejecuta el programa
	{
	}	
}

//*********************************************
// NON-Interrupt subroutines
void setup()
{
	cli(); // Se apagan las interruciones globales
	
	// Configurar presclaer de sistema
	CLKPR	= (1 << CLKPCE);
	CLKPR	= (1 << CLKPS2); // 16 PRESCALER -> 1MHz
	
	// Configuraci�n de Pines
	DDRD	= 0xFF;			// Se configura PORTD como salida
	PORTD	= 0x00;			// PORTD inicialmente apagado
	DDRB	= 0xFF;			// Se configura PORTD como salida
	PORTB	= 0x00;			// PORTD inicialmente apagado
	DDRC	= 0x00;			// Se configura PORTC como entrada
	PORTC	= 0x00;			// PORTC sin pull-up
	
	// Inicializaci�n de Variables
	
	// Inicio de PWM
	initPWM0A(0, 8);		// Se llama la funci�n de inicio del PWM del Timer1
	
	// Inicio de ADC
	initADC();
	ADCSRA	|= (1 << ADSC);	// Se hace la primera lectura del ADC
	
	// Configuraci�n de Interrupciones
	
	
	sei(); // Se encienden las interrupciones globales
}

void	 initADC()
{
	ADMUX	= 0;
	ADMUX	|= (1 << REFS0);
	ADMUX	|= (1 << ADLAR);
	ADMUX	&= ~((1 << MUX3) | (1 << MUX2) | (1 << MUX1) | (1 << MUX0));	// Se configura el PC0 y la justificaci�n
	
	ADCSRA	= 0;
	ADCSRA	|= (1 << ADPS2) | (1 << ADPS1);
	ADCSRA	|= (1 << ADIE);
	ADCSRA	|= (1 << ADEN);					// Se configura la interrupci�n y el prescaler
}


//*********************************************
// Interrupt�routines
ISR(ADC_vect)
{
	adc_read = ADCH;
	dutyCycle = ADC_to_PWM_Servo(adc_read);	// Se llama a la funci�n que mapea el ADC al servo
	updateDutyCycle_T1(dutyCycle);	// Se llama la funci�n que hace la actualizaci�n al registro
	_delay_ms(1);
	ADCSRA	|= (1 << ADSC);				// Se realiza la lectura de ADC
}


